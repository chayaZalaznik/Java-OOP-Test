package systemOrders;

import java.util.ArrayList;
import java.util.List;

public class Order {
	private static int nextId = 1;
	private  int id ;
	private String name;
    private String deliveryAddress;
    private List<Item> items;
    private Customer customer;
    private double totalPrice;
    private PaymentType paymentType;
    private String orderDate;

    public Order(String name, String deliveryAddress, List<Item> items, Customer customer, PaymentType paymentType, String orderDate) {
        this.id = nextId++;
        this.name = name;
        this.deliveryAddress = deliveryAddress;
        this.items = items;
        this.customer = customer;
        this.paymentType = paymentType;
        this.orderDate = orderDate;
        calculateTotalPrice();
        customer.addItemsToFavorite(items);

    }
    public enum PaymentType {
        CREDIT_CARD,
        PAYPAL,
        CASH
    }
    private void calculateTotalPrice() {
        double sum = 0;
        for (Item item : items) {
            sum += item.getPrice();
        }
        if (customer instanceof VIPCustomer) {
            VIPCustomer vipCustomer = (VIPCustomer) customer;
            double discount = vipCustomer.getDiscount();
            sum -= (sum * discount);
        }
        totalPrice = sum;
    }

    // Getters and setters

    public double getTotalPrice() {
        return totalPrice;
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDeliveryAddress() {
		return deliveryAddress;
	}

	public void setDeliveryAddress(String deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public PaymentType getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(PaymentType paymentType) {
		this.paymentType = paymentType;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", name=" + name + ", deliveryAddress=" + deliveryAddress + ", items=" + items
				+ ", customer=" + customer + ", totalPrice=" + totalPrice + ", paymentType=" + paymentType
				+ ", orderDate=" + orderDate + "]";
	}
	
}
