package systemOrders;

import java.util.ArrayList;
import java.util.List;

public class OrderManagementSystem {
    public static void main(String[] args) {
        // יצירת לקוחות
    	Customer customer1 = new Customer("213258213", "chaya", "Zalaznik", "john@example.com", "ramot", Customer.CustomerType.REGULAR) {
   	     @Override
   			public void openGift() {
			}};
         VIPCustomer customer2 = new VIPCustomer("2", "rivka", "lamet", "jane@example.com", "ramot", 0.1);

        // יצירת פריטים
        Item item1 = new Item("Shirt", 29.99);
        Item item2 = new Item("Pants", 49.99);
        Item item3 = new Item("Shoes", 79.99);

        // יצירת הזמנות
        List<Item> items1 = new ArrayList<>();
        items1.add(item1);
        items1.add(item2);
        Order order1 = new Order( "Order 1", "ramot", items1, customer1, Order.PaymentType.CREDIT_CARD, "2024-03-01");

        List<Item> items2 = new ArrayList<>();
        items2.add(item2);
        items2.add(item3);
        Order order2 = new Order( "Order 2", "ramot", items2, customer2, Order.PaymentType.PAYPAL, "2024-03-02");

        // הדפסת סכום כולל של הזמנה
        System.out.println("Total price of order 1: " + order1.getTotalPrice());
        System.out.println("Total price of order 2: " + order2.getTotalPrice());
        System.out.println(order1);
        System.out.println(order2);
        System.out.println(customer1.getFavoriteItems());
        // פתיחת מתנה על ידי לקוח VIP
        customer2.openGift();
    }
};

