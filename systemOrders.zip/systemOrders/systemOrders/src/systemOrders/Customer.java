package systemOrders;

import java.util.ArrayList;
import java.util.List;

public abstract class Customer {
    private String id;
    private String firstName;
    private String lastName;
    private String email;
    private String deliveryAddress;
    private CustomerType customerType;
    private List<Item> favoriteItems;
    private Gift gift;

    public Customer(String id, String firstName, String lastName, String email, String deliveryAddress, CustomerType customerType) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.deliveryAddress = deliveryAddress;
        this.customerType = customerType;
        this.favoriteItems = new ArrayList<>();
    }
    public enum CustomerType {
        REGULAR,
        VIP
    }
    public abstract void openGift();

    public void takeGift(Gift gift) {
        this.gift = gift;
    }
    public void addItemsToFavorite(List<Item> items) {
        for (Item item : items) {
            if (!favoriteItems.contains(item)) {
                favoriteItems.add(item);
            }
        }
    }

    public void updateFavoriteItems(List<Item> items) {
        favoriteItems.clear();
        favoriteItems.addAll(items);
    }
    // Getters and setters

    
    public String getFirstName() {
        return firstName;
    }

    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDeliveryAddress() {
		return deliveryAddress;
	}

	public void setDeliveryAddress(String deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}

	public CustomerType getCustomerType() {
		return customerType;
	}

	public void setCustomerType(CustomerType customerType) {
		this.customerType = customerType;
	}

	public Gift getGift() {
		return gift;
	}

	public void setGift(Gift gift) {
		this.gift = gift;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setFavoriteItems(List<Item> favoriteItems) {
		this.favoriteItems = favoriteItems;
	}

	public List<Item> getFavoriteItems() {
        return favoriteItems;
    }

	@Override
	public String toString() {
		return "Customer [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", deliveryAddress=" + deliveryAddress + ", customerType=" + customerType + ", favoriteItems="
				+ favoriteItems + ", gift=" + gift + "]";
	}
	
}