package systemOrders;

public class VIPCustomer extends Customer {
    private double discount;

    public VIPCustomer(String id, String firstName, String lastName, String email, String deliveryAddress, double discount) {
        super(id, firstName, lastName, email, deliveryAddress, CustomerType.VIP);
        this.discount = discount;
    }

    public double getDiscount() {
        return discount;
    }

    @Override
    public void openGift() {
        System.out.println("Congratulations! you got a new gift! Enjoy!");
    }

	@Override
	public String toString() {
		return "VIPCustomer [discount=" + discount + ", getDiscount()=" + getDiscount() + ", getFirstName()="
				+ getFirstName() + ", getId()=" + getId() + ", getLastName()=" + getLastName() + ", getEmail()="
				+ getEmail() + ", getDeliveryAddress()=" + getDeliveryAddress() + ", getCustomerType()="
				+ getCustomerType() + ", getGift()=" + getGift() + ", getFavoriteItems()=" + getFavoriteItems()
				+ ", toString()=" + super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ "]";
	}
    
    
}
